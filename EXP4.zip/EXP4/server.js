const express = require('express');
const expbs = require('express-handlebars');
const path = require('path');
const app = express();

app.use(express.urlencoded({ extended: true }));

app.engine('handlebars', expbs.engine({ defaultLayout: false }));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));  // Use absolute path

app.get('/', (req, res) => {
  res.render('index', { layout: false, title: 'Student Form' });
});

app.post('/', (req, res) => {
  res.send(req.body);
});

app.listen(2000, () => {
  console.log('Server running on http://localhost:2000');
});

// node -v,npm init -y, npm install express express-handlebars, node server.js

